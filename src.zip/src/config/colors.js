export const colors = {
  primary: '#8E97FD',
  white: '#ffff',
  whiteShade: '#FFECCC',
  whiteShadeBg: '#EBEAEC',
  gray: '#A1A4B2',
  bg: '#F2F3F7',
  heading: '#3F414E',
  facebookBg: '#7583CA',
};
